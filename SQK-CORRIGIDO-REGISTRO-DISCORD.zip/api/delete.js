// Kept for compatibility; all deletion uses the same permission checks and durable journal.
import manage from './manage.js';
export default function handler(req,res){const map={member:'remove_member',team:'remove_team',ranking:'clear_ranking'};req.body={...req.body,action:map[req.body?.action]||req.body?.action};return manage(req,res)}
