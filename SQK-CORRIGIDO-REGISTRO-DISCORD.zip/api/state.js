import {loadState} from '../lib/discord.js';
import {json,method,error,fail} from '../lib/http.js';
import {session} from '../lib/security.js';
import {project} from '../lib/state.js';
export default async function handler(req,res){if(!method(req,res,'GET'))return;try{const state=await loadState(),user=session(req,state);if(req.headers.authorization&&!user)fail('Sua sessão expirou. Entre novamente.',401);return json(res,200,project(state,user))}catch(e){return error(res,e)}}
