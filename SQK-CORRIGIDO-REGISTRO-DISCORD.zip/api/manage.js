import {loadState,appendOperation,apply} from '../lib/discord.js';
import {json,method,error,mutationGuard} from '../lib/http.js';
import {session} from '../lib/security.js';
import {project} from '../lib/state.js';
import {buildOperation} from '../lib/actions.js';
export default async function handler(req,res){
 if(!method(req,res,'POST'))return;
 try{mutationGuard(req);const state=await loadState(),user=session(req,state);const op=buildOperation(state,user,req.body||{});await appendOperation(op);apply(state,op);return json(res,200,{ok:true,state:project(state,user)})}catch(e){return error(res,e)}
}
