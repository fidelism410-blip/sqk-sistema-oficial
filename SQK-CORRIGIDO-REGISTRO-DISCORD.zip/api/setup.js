import {json,method} from '../lib/http.js';
export default function handler(req,res){if(!method(req,res,'POST'))return;return json(res,409,{error:'O registro existente deve ser preservado. Este pacote usa o DISCORD_STATE_MESSAGE_ID já configurado e não recria o banco.'})}
