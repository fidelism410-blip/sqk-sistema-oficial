import {loadState} from '../lib/discord.js';
import {json,method,error,fail,mutationGuard} from '../lib/http.js';
import {token,staffPassword,verifyPassword} from '../lib/security.js';
export default async function handler(req,res){
 if(!method(req,res,'POST'))return;
 try{mutationGuard(req);const {password='',username='',area='admin'}=req.body||{};if(typeof password!=='string'||password.length>200)fail('Credenciais inválidas',401);
 const role=area==='personalizada'?'habibi':area;
 if(['admin','habibi'].includes(role)){if(!staffPassword(role,password))fail('Senha incorreta',401);return json(res,200,{token:token({role}),role})}
 if(role!=='captain')fail('Acesso inválido');const state=await loadState();const c=state.captains.find(x=>x.username?.toLowerCase()===String(username).trim().toLowerCase());
 if(!c||c.active===false||!verifyPassword(password,c.passwordHash))fail('Usuário ou senha incorretos',401);
 return json(res,200,{token:token({role,id:c.id,authVersion:c.authVersion}),role});
 }catch(e){return error(res,e)}
}
