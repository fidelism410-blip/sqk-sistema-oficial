import assert from 'node:assert/strict';
import {server,messages,failDiscord} from './server.mjs';
import {loadState,appendOperation} from '../lib/discord.js';
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const base='http://127.0.0.1:'+server.address().port;
let count=0;async function request(path,body,token,expected=200){const r=await fetch(base+'/api/'+path,{method:body?'POST':'GET',headers:{...(body?{'Content-Type':'application/json'}:{}),...(token?{Authorization:'Bearer '+token}:{})},...(body?{body:JSON.stringify(body)}:{})});const data=await r.json();assert.equal(r.status,expected,JSON.stringify(data));count++;return data}
try{
 const admin=(await request('auth',{area:'admin',password:'test-admin-2026'})).token;
 const habibi=(await request('auth',{area:'habibi',password:'test-habibi-2026'})).token;
 await request('auth',{area:'admin',password:'test-habibi-2026'},null,401);
 await request('manage',{action:'create_team',name:'Denied'},null,401);
 await request('manage',{action:'create_team',name:'Denied'},habibi,403);
 let s=(await request('manage',{action:'create_team',name:'Test team',captain:'Cap'},admin)).state;const teamId=s.teams[0].id;
 s=(await request('manage',{action:'create_team',name:'Other team'},admin)).state;const otherId=s.teams[1].id;
 s=(await request('manage',{action:'captain',name:'Cap',username:'cap',password:'test-cap-2026',teamId,credentialed:false},admin)).state;const captainId=s.captains[0].id;
 const cap=(await request('auth',{area:'captain',username:'CAP',password:'test-cap-2026'})).token;
 s=(await request('manage',{action:'create_event',name:'Test event',format:'TRIO',rounds:5,date:'2026-10-02T20:30:00-03:00'},habibi)).state;const eventId=s.events[0].id;
 await request('manage',{action:'room',eventId,roomCode:'SECRET-ROOM',roomPassword:'SECRET-PASS'},habibi);
 let pub=await request('state');assert.equal(pub.events[0].hasCode,true);assert(!JSON.stringify(pub).includes('SECRET'));assert(!JSON.stringify(pub).includes('passwordHash'));
 let own=await request('state',null,cap);assert(!JSON.stringify(own).includes('SECRET'));
 await request('manage',{action:'credential',id:captainId,credentialed:true},admin);own=await request('state',null,cap);assert.equal(own.events[0].roomCode,'SECRET-ROOM');
 await request('manage',{action:'register',teamId:otherId,eventId,name:'Denied',players:['a','b','c']},cap,403);
 await request('manage',{action:'register',teamId,eventId,name:'Trio',players:['Alpha','Bravo','Charlie']},cap);
 await request('manage',{action:'register',teamId,eventId,name:'Trio updated',players:['Alpha','Bravo','Charlie']},cap);assert.equal((await loadState()).registrations.length,1);
 const score={action:'score',teamId,eventId,round:1,placement:1,players:[{nick:'Alpha',kills:10},{nick:'Bravo',kills:5},{nick:'Charlie',kills:5}]};
 await request('manage',score,cap);await request('manage',score,cap);assert.equal((await loadState()).scores.length,1);
 await request('manage',{...score,round:2,placement:6},cap);pub=await request('state');assert.equal(pub.ranking[0].pts,56);assert.equal(pub.ranking[0].kills,40);assert.equal(pub.ranking[0].drops,2);
 await request('manage',{...score,round:6},cap,400);await request('manage',{...score,players:[{nick:'Fake',kills:100}]},cap,400);
 const proof='data:image/png;base64,'+'A'.repeat(2400);await request('manage',{...score,proof},cap);assert.equal((await loadState()).scores.find(s=>s.round===1).proof,proof);assert(!JSON.stringify(await request('state')).includes(proof));
 const before=messages.length;failDiscord(true);await request('manage',{action:'add_member',teamId,nick:'Must not save'},cap,503);failDiscord(false);assert.equal(messages.length,before);
 // Two operations based on the same prior state are both retained.
 await Promise.all(['parallel-a','parallel-b'].map(id=>appendOperation({at:new Date().toISOString(),changes:[{collection:'members',upsert:[{id,teamId,nick:id}]}]})));
 assert.equal((await loadState()).members.length,2);
 await request('manage',{action:'event_status',eventId,status:'closed'},habibi);await request('manage',{action:'register',teamId,eventId,name:'Trio',players:['Alpha','Bravo','Charlie']},cap,400);
 await request('manage',{action:'credential',id:captainId,credentialed:false},admin);assert(!JSON.stringify(await request('state',null,cap)).includes('SECRET'));
 const original=messages[0].content;messages[0].content='corrupted';await request('state',null,null,503);messages[0].content=original;
 // Pagination over more than 100 messages must retain old operations.
 for(let i=0;i<101;i++)messages.push({id:String(10000+i),author:{id:'bot'},content:'non-operation audit',attachments:[]});assert.equal((await loadState()).scores.length,2);
 await request('manage',{action:'remove_team',id:teamId},admin);const final=await loadState();assert(!final.captains.length&&!final.registrations.length&&!final.scores.length);await request('state',null,cap,401);
 console.log(`PASS: ${count} API checks; persistence, legacy parsing, permissions, code secrecy, revocation, scores, large attachments, concurrency, pagination, corruption and deletion.`);
}finally{server.close()}
