// Local verification only. All Discord requests are intercepted in memory.
import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {blank} from '../lib/discord.js';
import auth from '../api/auth.js';import state from '../api/state.js';import manage from '../api/manage.js';import remove from '../api/delete.js';
process.env.DISCORD_BOT_TOKEN='local-test-signing-key';process.env.DISCORD_DATA_CHANNEL_ID='42';process.env.DISCORD_STATE_MESSAGE_ID='100';process.env.ADMIN_PASSWORD='test-admin-2026';process.env.PERSONALIZADA_PASSWORD='test-habibi-2026';
let next=100n;export const messages=[{id:'100',author:{id:'bot'},content:'```json\\n'+JSON.stringify(blank())+'\\n```',attachments:[]}];let unavailable=false;
export const failDiscord=value=>unavailable=value;
const nativeFetch=globalThis.fetch;const attachments=new Map();
globalThis.fetch=async(url,options={})=>{
 const u=new URL(url);if(u.hostname==='cdn.discordapp.com')return Response.json(attachments.get(u.pathname));if(u.hostname!=='discord.com')return nativeFetch(url,options);
 if(unavailable)return new Response('No permission',{status:403});
 if(options.method==='POST'){
  let body;if(options.body instanceof FormData){body=JSON.parse(options.body.get('payload_json'));const raw=await options.body.get('files[0]').text();const path='/test/'+String(next+1n);attachments.set(path,JSON.parse(raw));body.attachments=[{filename:'sqk-operation.json',url:'https://cdn.discordapp.com'+path}]}else body=JSON.parse(options.body);
  const message={...body,id:String(++next),author:{id:'bot'}};messages.push(message);return Response.json(message);
 }
 if(u.pathname.endsWith('/100'))return Response.json(messages[0]);
 const before=u.searchParams.get('before');return Response.json(messages.filter(m=>!before||BigInt(m.id)<BigInt(before)).slice().reverse().slice(0,100));
};
export const server=http.createServer(async(req,res)=>{
 const u=new URL(req.url,'http://localhost');res.status=n=>{res.statusCode=n;return res};res.json=data=>{res.setHeader('Content-Type','application/json');res.end(JSON.stringify(data))};
 try{if(u.pathname.startsWith('/api/')){const chunks=[];for await(const c of req)chunks.push(c);req.body=chunks.length?JSON.parse(Buffer.concat(chunks)):{};const handler={auth,state,manage,delete:remove}[u.pathname.slice(5)];if(!handler)return res.status(404).json({error:'not found'});return await handler(req,res)}
 const routes={'/':'index.html','/admin':'admin.html','/habibi':'habibi.html','/capitao':'capitao.html'};const file=routes[u.pathname]||u.pathname.slice(1);if(!/^[\w.-]+$/.test(file))return res.status(404).end();const ext=file.split('.').pop();res.setHeader('Content-Type',{html:'text/html',css:'text/css',js:'text/javascript',png:'image/png'}[ext]||'text/plain');res.end(await readFile(fileURLToPath(new URL('../public/'+file,import.meta.url))));
 }catch(e){res.status(500).json({error:e.message})}
});
if(process.argv[1]===fileURLToPath(import.meta.url))server.listen(3210,'127.0.0.1',()=>console.log('Local isolated test server http://127.0.0.1:3210'));
